# Fuentes y apoyos usados:
- Para el markdown y en general los formatos del notebook
    - https://www.edureka.co/blog/wp-content/uploads/2018/10/Jupyter_Notebook_CheatSheet_Edureka.pdf
    - https://ingeh.medium.com/markdown-for-jupyter-notebooks-cheatsheet-386c05aeebed
    - https://www.ibm.com/docs/en/db2-event-store/2.0.0?topic=notebooks-markdown-jupyter-cheatsheet
    
- Para la paleta de colores
    - https://coolors.co/palettes/trending

- Para la identificacion de que graficos usar y como
    - https://python-graph-gallery.com

- Para las diferentes funciones de pandas
    - Apuntes Lenguajes y Desarrollo de Soluciones IA
    - https://pandas.pydata.org/docs/

- Para los formatos y decoraciones de los graficos
    - https://matplotlib.org/stable/gallery/lines_bars_and_markers/scatter_star_poly.html
    
- Seabonrn: 
    - https://seaborn.pydata.org/examples/index.html

- Ayudas en como realizar algunas funciones estadisticas y de datasets:
    - Antiguo ejercicio propio que tengo en github: https://github.com/velkha/ProgramaIA_DS/tree/main/Codigo/Python/CalculadoraStPb