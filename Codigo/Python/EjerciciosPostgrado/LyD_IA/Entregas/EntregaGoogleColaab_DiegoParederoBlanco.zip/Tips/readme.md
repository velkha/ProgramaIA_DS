# Codigo del ejercicio:
    /py/tips_diegoparederoblanco.ipynb

# Algunas funciones usadas bsadas en otros ejercicios
    /py/lib/*

# Fuentes usadas para la realizacion del ejercicio
    /fuentes_y_herramientas

# Dataset usado para el ejercicio
    /data/tips.csv
