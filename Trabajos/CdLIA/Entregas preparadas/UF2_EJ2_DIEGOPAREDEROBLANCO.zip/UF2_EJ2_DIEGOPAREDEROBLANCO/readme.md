### Para el trabajo en su version UNIR

- Las miniguias estan todas sacadas a traves de diferentes IAs, principalmente GPT y Blackbox, algunas de ellas, especialmente las partes de desarrollo y codigo faltan por testearlas, ya que esto se hara a privado en la empresa mas adelante una vez debatida la implementacion mencionada
- El DocUnir muestra de una manera algo mas ficticia el entorno en el que estamos para no vulnerar datos privados, asi como ligeras modificaciones en el objetivo real del proyecto

